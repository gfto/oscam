//
// C++ Interface: %{MODULE}
//
// Description: 
//
//
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef SETUP_H
#define SETUP_H

#include <vdr/plugin.h>

enum MyThymes {DEEPBLUE=0, ENGIMA, ELCHI, MAXTHEME};

struct csmonTheme
{
  int      clrHeaderBkgr;
  int      clrHeaderText;
  int      clrClientBkgr;
  int      clrNormalText;
  int      clrSelectText;
  int      clrSelectBkgr;
  int      clrButtonRed;
  int      clrButtonGreen;
  int      clrButtonYellow;
  int      clrButtonBlue;
  int      clrButtonRedText;
  int      clrButtonGreenText;
  int      clrButtonYellowText;
  int      clrButtonBlueText;
  int      clrButtonBorder;
};

extern const csmonTheme csmonThemes[MAXTHEME];


struct Server
{
  char Host[100];
  int  Port;
  char Login[20];
  char Passwd[20];
};

#define MAXSERVER 8

class cCsmonSetup
{
public:
    int  NrServers;
    struct Server Server[MAXSERVER];
    
    int  StatusTimer;
    int  LogTimer;
    int  LogBuffer;

    enum MyThymes theme;
    int		realUserNumber;
    int		osdOffsetX;
    int		osdOffsetY; 

    cCsmonSetup();
    bool SetupParse(const char *Name, const char *Value);

};
extern cCsmonSetup csmonSetup;



class cCsmonSetupPage : public cMenuSetupPage
{
private:
  void Set();
  
protected:
  virtual void Store(void);
  virtual eOSState ProcessKey(eKeys Key);
public:
  
  cCsmonSetupPage(void);
};


#endif
