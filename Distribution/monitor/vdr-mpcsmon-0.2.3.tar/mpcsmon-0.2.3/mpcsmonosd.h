//
// C++ Interface: %{MODULE}
//
// Description:
//
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef NETMON_H
#define NETMON_H


#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <sstream>
#include <vdr/osd.h>
#include <vdr/tools.h>


#include "cscrypt/aes.h"
#include "cscrypt/md5.h"
#include "cscrypt/zlib.h"


using std::string;


#define LOGERR(str, args...)   {char *s=NULL; asprintf(&s, "CS-MON:ERROR %s",str ); esyslog(s, ##args ); free(s);}

// #define DEBUGMPCSMON

#ifdef DEBUGMPCSMON
#define LOGDBG(str, args...)   {char *s=NULL; asprintf(&s, "CS-MON:DEBUG %s",str ); dsyslog(s, ##args ); free(s);}
#else
#define LOGDBG(str, args...)
#endif


enum Onstate { NORMAL=0, SLEEPING, FAKEUSER};
class cCsUser : public cListObject
{
  private:

  public:

// pid|ptyp|nr|username|au|crypted|ip|port|prozess-typ|login-date|login-time|online|srvid|sendername|idle|onstate
    int     pid;
    string  type;
    int     nr;
    string  user;
    int     authenticated;
    int     crypted;
    string  ip;
    int     port;
    string  description;
    string  date;
    string  time;
    unsigned long  online;
    unsigned long  serviceId;
    string   channel;
    unsigned long  idle;
    enum Onstate   onstate;
    cCsUser (char *line)
        {
                char *p = NULL;
                char *buf =NULL;
                asprintf(&buf,line);
                pid           = 0;
                nr            = 0;
                authenticated = 0;
                crypted       = 0;
                port          = 0;
                online        = 0L;
                serviceId     = 0L;
                idle          = 0L;
                onstate       = NORMAL;

                if((p=strsep(&buf, "|")) != NULL) pid  = atoi(p);
                if((p=strsep(&buf, "|")) != NULL) type = p;
                if((p=strsep(&buf, "|")) != NULL) nr   = atoi(p);
                if((p=strsep(&buf, "|")) != NULL) user = p;
                if((p=strsep(&buf, "|")) != NULL) authenticated = atoi(p);
                if((p=strsep(&buf, "|")) != NULL) crypted = atoi(p);
                if((p=strsep(&buf, "|")) != NULL) ip   = p;
                if((p=strsep(&buf, "|")) != NULL) port = atoi(p);
                if((p=strsep(&buf, "|")) != NULL) description = p;
                if((p=strsep(&buf, "|")) != NULL) date   = p;
                if((p=strsep(&buf, "|")) != NULL) time   = p;
                if((p=strsep(&buf, "|")) != NULL) online = atol(p);
                if((p=strsep(&buf, "|")) != NULL) serviceId = atol(p);
                if((p=strsep(&buf, "|")) != NULL) channel = p;
                if((p=strsep(&buf, "|")) != NULL) idle    = atol(p);
                if((p=strsep(&buf, "|")) != NULL) onstate = (enum Onstate) atoi(p);

                free(buf);
              };

     ~cCsUser ()
              {
                Clear();
              };
      void Clear()
              {
                pid           = 0;
                nr            = 0;
                authenticated = 0;
                crypted       = 0;
                port          = 0;
                online        = 0L;
                serviceId     = 0L;
                idle          = 0L;
                onstate       = NORMAL;
              };

};

class cCsUsers : public cList<cCsUser> {};

/*
 * Logging
 */

static const cFont *nFont = cFont::GetFont(fontOsd);
static const cFont *sFont = cFont::GetFont(fontSml);

class cCsmonLog  : public cListObject
{
  private:
    string  time;
    string  type;
    string  user;
    string  caid;
    string  log;
  public:
    cCsmonLog(char *buf);
   ~cCsmonLog() { }

  string GetTime()   {return time;}	
  string GetType()   {return type;}
  string GetUser()   {return user;}
  string GetCaid()   {return caid;}
  string GetLog()    {return log;}
};

class cCsmonLogs  : public cList<cCsmonLog>{};

/*
 * COMMAND
 */
class cCsmonCommand : public cListObject
{
  private:
    string   text;
    string   command;
    bool     ask;
  public:
    cCsmonCommand(const char *Text, const char *Command, bool Ask=false){text=Text; command=Command; ask=Ask;}
    ~cCsmonCommand()    {}
    string GetText()   {return text;}
    string GetCommand(){return command;}
    bool   GetAsk()    {return ask;}
};

class cCsmonCommands : public cList<cCsmonCommand>{};

/*
 * OSD Classes
 */
class cCsmonArea
{
  public:
    int x1,y1;
    int x2,y2;
};

class cCsmonOsd : public cThread, public cOsdObject
{
  private:
    enum    Mode {IP=0, CHANNEL};
    enum    View {USER=0, READER, HIDEMONITOR, LOG, COMMAND, WAITFORCONFIRM};
    enum    Mode mode;
    enum    View view;
    int     sock;
    bool    connected;
    struct  sockaddr_in server;

    cCsmonLogs  logs;
    cCsUsers    users;
    cCsUsers    monitorUsers;
    cCsUsers    otherUsers;
    cCsmonCommands commands;
    time_t      logTime;
    time_t      statusTime;


    AES_KEY         d_key;
    AES_KEY         e_key;
    unsigned char   ucrc[4];

    cOsd     *osd;
    bool     run;
    int      currServer;

    int      current;
    int      firstLine;

    cCsmonArea totalArea;
    cCsmonArea headerArea;
    cCsmonArea clientArea;
    cCsmonArea buttonArea;
    int        maxNrOfLines;
    int        chw;

    int      clrHeaderBkgr;
    int      clrHeaderText;
    int      clrClientBkgr;
    int      clrNormalText;
    int      clrSelectText;
    int      clrSelectBkgr;
    int      clrButtonRed;
    int      clrButtonGreen;
    int      clrButtonYellow;
    int      clrButtonBlue;
    int      clrButtonRedText;
    int      clrButtonGreenText;
    int      clrButtonYellowText;
    int      clrButtonBlueText;
    int      clrButtonBorder;


    void    csmon_set_account(char *user, char *pwd);
    int     boundary(int exp, int n);
    void    csmon_set_key(unsigned char *key);
    unsigned char *i2b(int n, ulong i);


    void    AddUser(char *buf, bool first);
    void    AddLog(char *buf);
    char   *Strdupnew( const char  *str )  { return ( str ? strcpy(new char[strlen(str)+1],str) : 0);}
    bool    Connect(int serverNumber);
    void    Disconnect();
    int     Receive(unsigned char *buf, int len);
    int     Receive(unsigned char *buf, int len, int sec);
    int     ReceiveLine(char *buf, int sec);
    void    ChkReceive();
    void    Send(const char *command);
    void    ShowClients();
    void    ShowOtherClients();
    void    AlignCoordinates(int x1, int  y1, int &x2, int &y2, int bpp);
    void    SwitchView(enum View _view );
  protected:
    virtual void Action(void);


public:
    cCsmonOsd();
   ~cCsmonOsd();
   void PleaseWait();
   void DrawMenu();
   void DrawClients();
   void DrawUsersOnly();
   void DrawOtherClients( );
   void DrawLogs();


   bool Confirm(string msg);
   void DrawCommands();
   void DrawMessage(const char *msg);
   void SetButton( const char * redText, const char * greenText, const char * yellowText,
                              const char * blueText );
   void DrawBorder(int x1, int y1, int x2, int y2, int width, int color);
   void DrawBorder(int x1, int y1, int x2, int y2, int width, int borderColor, int fillColor);
   void DrawEclipseBorder( int x1, int y1, int x2, int y2, int radius, int color );
   void DrawEclipseFrame( int x1, int y1, int x2, int y2, int radius, int selectBack, int background );
   void DrawScrollBar(int totalElements, int maxElements);
   void DisplayBitmap();
   void ClearBitmap();

   void Scroll( eKeys Key );
   virtual void Show(void);
   virtual eOSState ProcessKey(eKeys Key);

};

#endif

