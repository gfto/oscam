/*********************************************************
 * DESCRIPTION: 
 *             Header File
 *
 *
 *
 *********************************************************/

#ifndef _I18N__H
#define _I18N__H

#include <vdr/i18n.h>

extern const tI18nPhrase Phrases[];

#endif //_I18N__H
