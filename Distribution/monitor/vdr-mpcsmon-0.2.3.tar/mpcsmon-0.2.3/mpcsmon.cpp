/*
 * csmon.cpp: A plugin for the Video Disk Recorder
 *
 * See the README file for copyright information and how to reach the author.
 *
 */

#include <vdr/plugin.h>
#include "i18n.h"
#include "mpcsmonosd.h"
#include "setup.h"


static const char *VERSION        = "0.2.3";
static const char *DESCRIPTION    = "MPCS Cardserver Monitor";
static const char *MAINMENUENTRY  = "MPCS-Monitor";

class cPluginCsmon : public cPlugin {
private:
  // Add any member variables or functions you may need here.
public:
  cPluginCsmon(void);
  virtual ~cPluginCsmon();
  virtual const char *Version(void) { return VERSION; }
  virtual const char *Description(void) { return DESCRIPTION; }
  virtual const char *CommandLineHelp(void);
  virtual bool ProcessArgs(int argc, char *argv[]);
  virtual bool Initialize(void);
  virtual bool Start(void);
  virtual void Stop(void);
  virtual void Housekeeping(void);
  virtual const char *MainMenuEntry(void) { return MAINMENUENTRY; }
  virtual cOsdObject *MainMenuAction(void);
  virtual cMenuSetupPage *SetupMenu(void);
  virtual bool SetupParse(const char *Name, const char *Value);
  };

cPluginCsmon::cPluginCsmon(void)
{
  // Initialize any member variables here.
  // DON'T DO ANYTHING ELSE THAT MAY HAVE SIDE EFFECTS, REQUIRE GLOBAL
  // VDR OBJECTS TO EXIST OR PRODUCE ANY OUTPUT!
}

cPluginCsmon::~cPluginCsmon()
{
  // Clean up after yourself!
}

const char *cPluginCsmon::CommandLineHelp(void)
{
  // Return a string that describes all known command line options.
  return NULL;
}

bool cPluginCsmon::ProcessArgs(int argc, char *argv[])
{
  // Implement command line argument processing here if applicable.
  return true;
}

bool cPluginCsmon::Initialize(void)
{
  // Initialize any background activities the plugin shall perform.
  RegisterI18n(Phrases);
  return true;
}

bool cPluginCsmon::Start(void)
{
  // Start any background activities the plugin shall perform.
  return true;
}

void cPluginCsmon::Stop(void)
{
  // Stop any background activities the plugin shall perform.
}

void cPluginCsmon::Housekeeping(void)
{
  // Perform any cleanup or other regular tasks.
}

cOsdObject *cPluginCsmon::MainMenuAction(void)
{
  // Perform the action when selected from the main VDR menu.
  return new cCsmonOsd;
}

cMenuSetupPage *cPluginCsmon::SetupMenu(void)
{
  // Return a setup menu in case the plugin supports one.
  return new cCsmonSetupPage;
}

bool cPluginCsmon::SetupParse(const char *Name, const char *Value)
{
  // Parse your own setup parameters and store their values.
  return csmonSetup.SetupParse(Name, Value);
  ;
}
//holds setup configuration
cCsmonSetup  csmonSetup;

VDRPLUGINCREATOR(cPluginCsmon); // Don't touch this!
