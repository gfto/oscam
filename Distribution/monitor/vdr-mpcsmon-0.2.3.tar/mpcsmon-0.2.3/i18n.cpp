/****************************************************************************
 * DESCRIPTION:
 *             Internationalisation Strings
 * 		Copyright (C) 2004 by
 ****************************************************************************/
#include "i18n.h"

const tI18nPhrase Phrases[] = {
  {
    "Host",
    "Host",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�

  },
  {
    "Port",
    "Port",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },

  {
    "Nr",
    "Nr",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
 {
   "CA",
   "CA",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
 {
    "User",
    "Nutzer",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
  {
    "User/Monitor",
    "Nutzer/Monitor",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
   {
    "Clear Log",
    "Log l�schen",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
  {
    "IP:Port",
    "IP:Port",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
 {
    "PID",
    "PID",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
 {
    "Online",
    "Online",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },

  {
    "Please Wait ...",
    "Bitte warten ...",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },

  {
    "Connection failed ...",
    "Verbindung fehlgeschlagen",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },


  {
    "Resend Status (s)",
    "Wiederhole Status (s)",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
  {
    "Resend Log (s)",
    "Wiederhole Log (s)",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
  {
    "Channel",
    "Sender",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },

  {
    "Reader",
    "Reader",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },

  {
    "Log",
    "Log",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },

  {
    "On",
    "On",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
  {
    "AU",
    "AU",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },

  {
    "IP / PID",
    "IP / PID",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
  {
    "Protocol",
    "Protokoll",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },

  {
    "Idle",
    "Idle",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
  {
    "Typ",
    "Typ",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },

  {
    "Commands",
    "Befehle",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },

  {
    "Shutdown MPCS-Server",
    "MPCS-Server beenden",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },

  {
    "Reload User DB",
    "Benutzer DB neu laden",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
  {
    "Log-Buffer-Size",
    "Gr��e des Log-Buffers",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Ellinika
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
  {
    "Server",
    "Server",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
{
    "RealUserNumber",
    "User Nr. des Servers anzeigen",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
  {
    "CS-Time",
    "CS-Zeit",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
  },
  {
    "Select Command with up/down key and with ok key confirm this",
    "Kommando mit auf/ab ausw�hlen und mit ok Taste best�tigen",
    "",// TODO Slovenski
    "",// TODO Italiano
    "",// TODO Nederlands
    "",// TODO Portugu�s
    "",// TODO Francais
    "",// TODO Norsk
    "",// TODO suomi
    "",// TODO Polski
    "",// TODO Espa�ol
    "",// TODO Svenska
    "",// TODO Romaneste
    "",// TODO Magyar
    "",// TODO Catal�
    },

  { NULL }
};
