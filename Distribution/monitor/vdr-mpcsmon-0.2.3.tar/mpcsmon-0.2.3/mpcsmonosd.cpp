//
// C++ Implementation: %{MODULE}
//
// Description:
//
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include <vector>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <vdr/plugin.h>

#ifndef VDRVERSNUM
#include <vdr/config.h>
#endif

#include "mpcsmonosd.h"
#include "setup.h"




#define LINE_SPACING  1
#define LINEHEIGHT (sFont->Height() + LINE_SPACING)
#define SCROLLWIDTH  20
#define SCROLLOFFSET  2


using std::string;
using std::vector;
using std::stringstream;


void Tokenize(const string& str,
                      vector<string>& tokens,
                      const string& delimiters = " ")
{
    // Skip delimiters at beginning.
    string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    // Find first "non-delimiter".
    string::size_type pos     = str.find_first_of(delimiters, lastPos);

    while (string::npos != pos || string::npos != lastPos)
    {
        // Found a token, add it to the vector.
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        // Skip delimiters.  Note the "not_of"
        lastPos = str.find_first_not_of(delimiters, pos);
        // Find next "non-delimiter"
        pos = str.find_first_of(delimiters, lastPos);
    }
}


cCsmonLog::cCsmonLog(char *buf)
{
      //Strip Log
      vector<string>    token;
      string            l = buf;
      string::size_type p1 = l.find('(');
      string::size_type p2 = l.rfind("&");
      unsigned int      logstart = 4;

      Tokenize(l, token, " ");

      if( token.size() > 3)
      {
        time	= token[0];
        type	= token[2];
        user	= token[3];
      }


      if( p1 != string::npos && p2 != string::npos)
      {
        caid = l.substr(p1+1, p2-p1-1);
	logstart = 5;
      }

     for( unsigned int i = logstart; i<token.size(); i++)
         log = log + " " +token[i];

}

cCsmonOsd::cCsmonOsd()
{
  currServer = 0;
  sock       = 0;
  connected  = false;
  mode       = CHANNEL;
  view       = USER;
  run        = false;
  osd        = NULL;


  logTime       = 0;
  statusTime    = 0;

  chw =sFont->Width('0');
  current     = 0;
  firstLine   = 0;

  clrHeaderBkgr = csmonThemes[csmonSetup.theme].clrHeaderBkgr;
  clrHeaderText = csmonThemes[csmonSetup.theme].clrHeaderText;
  clrClientBkgr = csmonThemes[csmonSetup.theme].clrClientBkgr;
  clrNormalText = csmonThemes[csmonSetup.theme].clrNormalText;
  clrSelectText = csmonThemes[csmonSetup.theme].clrSelectText;
  clrSelectBkgr = csmonThemes[csmonSetup.theme].clrSelectBkgr;


  clrButtonRed    = csmonThemes[csmonSetup.theme].clrButtonRed;
  clrButtonGreen  = csmonThemes[csmonSetup.theme].clrButtonGreen;
  clrButtonYellow = csmonThemes[csmonSetup.theme].clrButtonYellow;
  clrButtonBlue   = csmonThemes[csmonSetup.theme].clrButtonBlue;

  clrButtonRedText    = csmonThemes[csmonSetup.theme].clrButtonRedText;
  clrButtonGreenText  = csmonThemes[csmonSetup.theme].clrButtonGreenText;
  clrButtonYellowText = csmonThemes[csmonSetup.theme].clrButtonYellowText;
  clrButtonBlueText   = csmonThemes[csmonSetup.theme].clrButtonBlueText;
  clrButtonBorder     = csmonThemes[csmonSetup.theme].clrButtonBorder;


  commands.Add(new cCsmonCommand(tr("Reload User DB"), "reload\n",  true));
  commands.Add(new cCsmonCommand(tr("Shutdown MPCS-Server"), "shutdown\n", true));
}


cCsmonOsd::~cCsmonOsd()
{
  run=false;
  Disconnect();
  cCondWait::SleepMs(200);
  Cancel(0);
  Unlock();

  if(osd != NULL) delete  osd;

}

void cCsmonOsd::csmon_set_key(unsigned char *key)
{
  AES_set_encrypt_key(key, 128, &e_key);
  AES_set_decrypt_key(key, 128, &d_key);
}


void cCsmonOsd::csmon_set_account(char *user, char *pwd)
{
  unsigned long c;


  c=crc32(0L,MD5((unsigned char*)user, strlen(user), NULL), 16);
  ucrc[0]=(c>>24) & 0xff; ucrc[1]=(c>>16) & 0xff;
  ucrc[2]=(c>> 8) & 0xff; ucrc[3]=(c    ) & 0xff;
  csmon_set_key(MD5((unsigned char*)pwd, strlen(pwd), NULL));
}

int cCsmonOsd::boundary(int exp, int n)
{
  return((((n-1)>>exp)+1)<<exp);
}

unsigned char *cCsmonOsd::i2b(int n, ulong i)
{
  static unsigned char b[4];
  switch(n)
  {
    case 2:
      b[0]=(i>> 8) & 0xff;
      b[1]=(i    ) & 0xff;
      break;
    case 4:
      b[0]=(i>>24) & 0xff;
      b[1]=(i>>16) & 0xff;
      b[2]=(i>> 8) & 0xff;
      b[3]=(i    ) & 0xff;
      break;
  }
  return(b);
}



// -------- Network Methods ---------------------

bool cCsmonOsd::Connect(int serverNumber)
{
  connected = false;
  struct hostent *rht;


   if ((sock=socket(PF_INET, SOCK_DGRAM, 0))<0)
   {
     LOGERR("create Socket failed. errno =%d\n", errno);
   }
   else
   { connected =true;
   if( (rht = gethostbyname(csmonSetup.Server[serverNumber].Host)) == NULL)
     {
       LOGERR("Unknown host: %s", csmonSetup.Server[serverNumber].Host);
     }
      else
      {
          server.sin_family = AF_INET;
          bcopy((char *)rht->h_addr,
                (char *)&server.sin_addr,
                rht->h_length);
          server.sin_port = htons(csmonSetup.Server[serverNumber].Port);
        connected =true;
        csmon_set_account(csmonSetup.Server[serverNumber].Login, csmonSetup.Server[serverNumber].Passwd);
      }
   }

  return(connected);
}


void cCsmonOsd::Disconnect( )
{
    if(connected)
    {
      Send("exit\n");
      close(sock);
    }
    connected = false;
}

int cCsmonOsd::Receive(unsigned char *buf, int len )
{
  socklen_t from = len;
  int i, n;

  if(! connected) return(-1);

  if ((n=recvfrom(sock, buf, len, 0, (struct sockaddr*)&server, &from))<10)
    return(-1);
  if (buf[0]!='&')      // not crypted
    return(-1);
  if (memcmp(buf+1, ucrc, 4))   // wrong user crc
    return(-1);
  for(i=0; i<(n-5); i+=16)
    AES_decrypt(buf+5+i, buf+5+i, &d_key);
  if (memcmp(buf+5, i2b(4, crc32(0L, buf+10, n-10)), 4))
  {
    LOGERR("CSMON: CRC error while receiving ! wrong password ?\n");
    return(-1);
  }
  n=buf[9];
  buf[10+n]='\0';
  memmove(buf, buf+10, n+1);
  return(n);
}

int cCsmonOsd::Receive(unsigned char *buf, int len, int sec)
{
  struct timeval tv;
  fd_set fds;
  int rc = -1;

  if(connected)
  {
    tv.tv_sec = sec;
    tv.tv_usec = 0;
    FD_ZERO(&fds);
    FD_SET(sock, &fds);

    select(sock+1, &fds, 0, 0, &tv);

    rc=-1;
    if (FD_ISSET(sock, &fds))
      if (!(rc=Receive(buf, len)))
        rc=-1;


  }
  return(rc);
}


void cCsmonOsd::Send( const char * command )
{
  LOGDBG("Send command=%s\n", command);

  int i, l;
  unsigned char buf[256+32];
  buf[0]='&';
  buf[9]=strlen(command);
  l=boundary(4, buf[9]+5)+5;
  strcpy((char*)buf+10, command);
  memcpy(buf+5, i2b(4, crc32(0L, buf+10, l-10)), 4);
  for(i=0; i<(l-5); i+=16)
    AES_encrypt(buf+5+i, buf+5+i, &e_key);
  memcpy(buf+1, ucrc, 4);


  if( sendto(sock, buf, l, 0, (struct sockaddr*) &server, sizeof(server)) == -1)
    LOGERR("Error in sending command =%s  errno=%d, %s\n", buf, errno,strerror(errno) );
}

int cCsmonOsd::ReceiveLine( char * buf, int sec )
{
  int r, done=0;
  char *ptr;
  static char lbuf[4096];
  static int p=0;
  buf[0]='\0';
  while (!done)
  {
    lbuf[p]=0;
    if ((ptr=strchr((const char*)lbuf, (int)'\n')) != NULL)
    {
      *ptr=0;
      strcpy(buf, lbuf);
      ptr++;
      p-=ptr-lbuf;
      if (p>0) memmove(lbuf, ptr, p+1);
      done=1;
    }
    else
    {
      if ((r=Receive((unsigned char*)lbuf+p, sizeof(lbuf)-p, sec))>0)
        p+=r;
      else
        done=1;
    }
  }
  return(buf[0]);
}


void cCsmonOsd::ChkReceive()
{
  bool rflog    = false;
  bool rfclient = false;
  char txt[512];
  time_t  currTime;

  LOGDBG("In ChkReceive\n");

  if(connected)
  {
    LOGDBG("In ChkReceive connected==true\n");
    rflog=rfclient=0;
    while (ReceiveLine(txt, 4))
    {
      currTime = time(NULL);
      LOGDBG("receive: {%s}\n", txt);

      if ((strlen(txt)<8)||(txt[0]!='[')||(txt[7]!=']')) continue;
      switch (txt[1])
      {
        case 'L':
                  AddLog(txt+19);
                  rflog=true;
                  logTime = currTime;
                  DrawMenu();
                  break;
        case 'I':
                  AddUser(txt+8, txt[2]=='S' || txt[2]=='B');
                  rfclient = (txt[2]=='E') || txt[2]=='S' ;
                  statusTime =  currTime;
                  if( rfclient ) DrawMenu();
                  break;
      }
      if( currTime >= logTime + csmonSetup.LogTimer )
      {
        //may be packet is lost so send command again
        LOGDBG("Resend Command: \"log on\"\n");
        Send("log on\n");
        logTime = currTime;
      }

      if( currTime >= statusTime + csmonSetup.StatusTimer )
      {
        //may be packet is lost so send command again
        LOGDBG("Resend Command: \"status\"\n");
        Send("status\n");
        statusTime =  currTime;
      }
    }

    if( !rflog && !rfclient)
    {
      //may be packet is lost so send command again
      LOGDBG("Resend Commands\n");
      Send("log on\n");
      Send("status\n");
    }
  }

}

void cCsmonOsd::AddUser( char * buf, bool first )
{

  Lock();
  if( first )
  {
    users.Clear();
    monitorUsers.Clear();
    otherUsers.Clear();
  }

  cCsUser *user = new cCsUser(buf);

  if( user->type.length() >0 )
  {
    if( user->type[0] == 'c' )
      users.Add(user);

    if( user->type[0] == 'c'  || user->type[0] == 'm' )
    {
      cCsUser *monitorUser = new cCsUser(buf);
      monitorUsers.Add(monitorUser);
    }
    else
      otherUsers.Add(user);
  }
  Unlock();
}

void cCsmonOsd::AddLog( char * buf)
{
   Lock();
   logs.Ins(new cCsmonLog(buf), logs.First());
   Unlock();
}


void cCsmonOsd::ShowClients( )
{
  LOGDBG("ShowClients :: Nr User=%d\n", users.Count());
  for( int i=0; i<users.Count(); i++)
  {
    LOGDBG("Client[%d] pid=%d\n", i, users.Get(i)->pid);
    LOGDBG("Client[%d] type=%s\n", i, users.Get(i)->type.c_str());
    LOGDBG("Client[%d] nr=%d\n", i, users.Get(i)->nr);
    LOGDBG("Client[%d] usr=%s\n", i, users.Get(i)->user.c_str());
    LOGDBG("Client[%d] auth=%d\n", i, users.Get(i)->authenticated);
    LOGDBG("Client[%d] crypted=%d\n", i, users.Get(i)->crypted);
    LOGDBG("Client[%d] ip=%s\n", i, users.Get(i)->ip.c_str());
    LOGDBG("Client[%d] channel=%s\n", i, users.Get(i)->channel.c_str());
    LOGDBG("Client[%d] port=%d\n", i, users.Get(i)->port);
    LOGDBG("Client[%d] description=%s\n", i, users.Get(i)->description.c_str());
    LOGDBG("Client[%d] date=%s\n", i, users.Get(i)->date.c_str());
    LOGDBG("Client[%d] time=%s\n", i, users.Get(i)->time.c_str());
    LOGDBG("Client[%d] online=%ld\n",i,  users.Get(i)->online);
    LOGDBG("Client[%d] idle=%ld\n",i,  users.Get(i)->idle);
    LOGDBG("Client[%d] onstate=%ld\n",i,  users.Get(i)->onstate);
    LOGDBG("\n")    ;
  }
}
void cCsmonOsd::ShowOtherClients( )
{
  LOGDBG("ShowOtherClients :: Nr User=%d\n", otherUsers.Count());
  for( int i=0; i<otherUsers.Count(); i++)
  {
    LOGDBG("Client[%d] pid=%d\n",  i, otherUsers.Get(i)->pid);
    LOGDBG("Client[%d] type=%s\n", i, otherUsers.Get(i)->type.c_str());
    LOGDBG("Client[%d] nr=%d\n",   i, otherUsers.Get(i)->nr);
    LOGDBG("Client[%d] usr=%s\n",  i, otherUsers.Get(i)->user.c_str());
    LOGDBG("Client[%d] auth=%d\n", i, otherUsers.Get(i)->authenticated);
    LOGDBG("Client[%d] crypted=%d\n", i, otherUsers.Get(i)->crypted);
    LOGDBG("Client[%d] ip=%s\n",   i, otherUsers.Get(i)->ip.c_str());
    LOGDBG("Client[%d] channel=%s\n", i, otherUsers.Get(i)->channel.c_str());
    LOGDBG("Client[%d] port=%d\n", i, otherUsers.Get(i)->port);
    LOGDBG("Client[%d] description=%s\n", i, otherUsers.Get(i)->description.c_str());
    LOGDBG("Client[%d] date=%s\n", i, otherUsers.Get(i)->date.c_str());
    LOGDBG("Client[%d] time=%s\n", i, otherUsers.Get(i)->time.c_str());
    LOGDBG("Client[%d] online=%ld\n",i,  otherUsers.Get(i)->online);
    LOGDBG("Client[%d] idle=%ld\n",i,  otherUsers.Get(i)->idle);
    LOGDBG("Client[%d] onstate=%ld\n",i,  otherUsers.Get(i)->onstate);
    LOGDBG("\n")    ;
  }
}

//-----------------------------------------------------------------------------

void cCsmonOsd::Show() {
  int ret;

  totalArea.x1=0;
  totalArea.y1=0;
  totalArea.x2 = Setup.OSDWidth -1;
  totalArea.y2 = Setup.OSDHeight-1;
  AlignCoordinates(totalArea.x1, totalArea.y1, totalArea.x2, totalArea.y2, 4);

  headerArea.x1= totalArea.x1;
  headerArea.y1= totalArea.y1;
  headerArea.x2= totalArea.x2;
  headerArea.y2= totalArea.y1 + sFont->Height()+sFont->Height();
  AlignCoordinates(headerArea.x1, headerArea.y1, headerArea.x2, headerArea.y2, 2);

  clientArea.x1= totalArea.x1;
  clientArea.y1= headerArea.y2 +1;
  clientArea.x2= totalArea.x2;
  clientArea.y2= totalArea.y2 - 2*sFont->Height() -1;
  AlignCoordinates(clientArea.x1, clientArea.y1, clientArea.x2, clientArea.y2, 2);

  buttonArea.x1= totalArea.x1;
  buttonArea.y1= clientArea.y2+1;
  buttonArea.x2= totalArea.x2;
  buttonArea.y2= totalArea.y2;
  AlignCoordinates(clientArea.x1, clientArea.y1, clientArea.x2, clientArea.y2, 2);

  maxNrOfLines= (clientArea.y2-clientArea.y1) / (sFont->Height()+LINE_SPACING);

  int offsetX = Setup.OSDLeft+ csmonSetup.osdOffsetX;
  int offsetY = Setup.OSDTop + csmonSetup.osdOffsetY;
  if(offsetX<0) offsetX=0;
  if(offsetY<0) offsetY=0;

  osd = cOsdProvider::NewOsd( offsetX, offsetY);
  if(osd)
  {
    tArea Area [] = {{  totalArea.x1,  totalArea.y1, totalArea.x2,  totalArea.y2, 4 }};
    if (osd->CanHandleAreas(Area, 1) == oeOk)
      ret = osd->SetAreas(Area, 1);
    else
    {
      tArea Area[] ={
        { headerArea.x1,  headerArea.y1, headerArea.x2,  headerArea.y2, 2 },
        { clientArea.x1,  clientArea.y1, clientArea.x2,  clientArea.y2, 2 },
        { buttonArea.x1,  buttonArea.y1, buttonArea.x2,  buttonArea.y2, 4 },
      };

      ret = osd->SetAreas(Area, sizeof(Area) / sizeof(tArea));
    }

    if(ret !=oeOk)
    {
      const char *errormsg = NULL;
      switch (ret)
      {
        case oeTooManyAreas:
          errormsg = "Too many OSD areas"; break;
        case oeTooManyColors:
          errormsg = "Too many colors"; break;
        case oeBppNotSupported:
          errormsg = "Depth not supported"; break;
        case oeAreasOverlap:
          errormsg = "Areas are overlapped"; break;
        case oeWrongAlignment:
          errormsg = "Areas not correctly aligned"; break;
        case oeOutOfMemory:
          errormsg = "OSD memory overflow"; break;
        case oeUnknown:
          errormsg = "Unknown OSD error"; break;
        default:
          break;
      }
      esyslog("MPCSMON: ERROR! OSD open failed! Can't handle areas (%d)-%s\n", ret, errormsg);
    }
    else
    {
      run=true;
      PleaseWait();
      Start();
    }
  }
}

void cCsmonOsd::PleaseWait()
{
  Lock();
  ClearBitmap();
  osd->DrawText(20, 20, tr("Please Wait ..."), clrNormalText, clrTransparent,sFont);
  DisplayBitmap();

  users.Clear();
  logs.Clear();
  otherUsers.Clear();
  monitorUsers.Clear();
  Disconnect();
  if( Connect(currServer))
  {
    time_t currTime = time(NULL);
    logTime    = currTime;
    statusTime = currTime;
    Send("log on\n");
    Send("status\n");
  }
  Unlock();
}

void cCsmonOsd::Action()
{
  while(run)
  {
    ChkReceive();
  }
  Unlock();
}




void cCsmonOsd::DrawMenu()
{
  const char * red    = NULL;
  const char * green  = NULL;
  const char * yellow = NULL;
  const char * blue   = NULL;

  Lock();
  ClearBitmap();

  switch(view)
  {
    case USER:
      red    = tr("User");
      yellow = tr("Commands");
      if (csmonSetup.NrServers >1)
        blue   = tr("Server");
      mode == IP ? green = tr("Channel") : green=tr("IP / PID");
      DrawClients();
      break;
    case HIDEMONITOR:
      red    = tr("Reader");
      yellow = tr("Commands");
      if (csmonSetup.NrServers >1)
        blue   = tr("Server");
      mode == IP ? green = tr("Channel") : green=tr("IP / PID");
      DrawUsersOnly();
    break;
    case READER:
      red    = tr("Log");
      yellow = tr("Commands");
      if (csmonSetup.NrServers >1)
        blue   = tr("Server");
      mode == IP ? green = tr("Channel") : green=tr("IP / PID");
      DrawOtherClients();
    break;
    case LOG:
      red    = tr("User/Monitor");
      yellow = tr("Commands");
      if (csmonSetup.NrServers >1)
        blue   = tr("Server");
      DrawLogs();
    break;
    case COMMAND:
    case WAITFORCONFIRM:
      DrawCommands();
      if (csmonSetup.NrServers >1)
      blue = tr("Server");
      red = tr("User/Monitor");
    break;
  }

  SetButton(red, green, yellow, blue );

  DisplayBitmap();
  Unlock();
}

void cCsmonOsd::SwitchView(enum View _view )
{
  view    = _view;
  current = 0;
  DrawMenu();
}

/*
 *  Draw User Screen
 */
void cCsmonOsd::DrawUsersOnly( )
{
  char *tmp;
  stringstream  title;
  int y;
  int circleX1      = 8;
  int circleY1      = 7;
  int circleX2      = 18;
  int circleY2      = 17;

  int t1=5;          //Nr
  int t2=t1+3*chw;   //On
  int t3=t2+3*chw;   //AU
  int t4=t3+3*chw;   //User
  int t5=t4+10*chw;  //Protocol
  int t6=t5+10*chw;  //IP:Port /Channel
  int t7=headerArea.x2-SCROLLWIDTH-SCROLLOFFSET-6*chw;   //Online / PID

  // Header Area
  DrawBorder(headerArea.x1, headerArea.y1, headerArea.x2, headerArea.y2, 2, clrHeaderText, clrHeaderBkgr );

  y = headerArea.y1;
  title << "MPCS-Monitor - Users-Info - " << csmonSetup.Server[currServer].Host;


  osd->DrawText(headerArea.x1,    y, title.str().c_str(), clrHeaderText,
                clrTransparent,sFont,headerArea.x2-headerArea.x1,0, taCenter);

  y += sFont->Height()+1;
  osd->DrawText(t1,    y, tr("Nr"),    clrHeaderText, clrTransparent,sFont);
  osd->DrawText(t2,    y, tr("On"),    clrHeaderText, clrTransparent,sFont);
  osd->DrawText(t3,    y, tr("AU"),    clrHeaderText, clrTransparent,sFont);
  osd->DrawText(t4,    y, tr("User"),  clrHeaderText, clrTransparent,sFont);
  osd->DrawText(t5,    y, tr("Protocol"),clrHeaderText, clrTransparent,sFont);

  if( mode == IP)
  {
    osd->DrawText(t6, y, tr("IP:Port"),  clrHeaderText, clrTransparent,sFont);
    osd->DrawText(t7, y, tr("PID"),      clrHeaderText, clrTransparent,sFont);
  }
  else
  {
   osd->DrawText(t6,    y, tr("Channel"), clrHeaderText, clrTransparent,sFont);
   osd->DrawText(t7,    y, tr("Online"),  clrHeaderText, clrTransparent,sFont);
  }


 //Delimiter Line
  osd->DrawRectangle(headerArea.x1, y, headerArea.x2, y+1, clrHeaderText);



  // Client Area
  y = clientArea.y1;
  for(int i=0; i<users.Count()&& i<maxNrOfLines; i++)
  {
    if(!csmonSetup.realUserNumber)
    {
        asprintf(&tmp, "%2d",  i+1);
    } else {
        asprintf(&tmp, "%2d", users.Get(i+current)->nr);
    }
    osd->DrawText(t1, y, tmp, clrNormalText, clrTransparent,sFont,  t2-t1, 0, taLeft);
    free(tmp);

    switch(users.Get(i+current)->onstate)
    {
      case NORMAL:
        osd->DrawEllipse(t2+circleX1,   y+circleY1,
                         t2+circleX2,   y+circleY2,
                         clrButtonGreen);
        break;
      case SLEEPING:
        osd->DrawEllipse(t2+circleX1,   y+circleY1,
                         t2+circleX2,   y+circleY2,
                         clrNormalText);
        break;
      case FAKEUSER:
        osd->DrawEllipse(t2+circleX1,   y+circleY1,
                         t2+circleX2,   y+circleY2,
                         clrButtonRed);
        break;
      default:
        LOGERR("MPCSMON: Unknown onstate=%d\n", users.Get(i+current)->onstate);
        break;
    }


    if( users.Get(i+current)->authenticated > 0)
    {
      osd->DrawEllipse(t3+circleX1,   y+circleY1,
                       t3+circleX2,   y+circleY2,
                       clrButtonGreen);
    }
    else
    if( users.Get(i+current)->authenticated == 0)
    {
      osd->DrawEllipse(t3+circleX1,   y+circleY1,
                       t3+circleX2,   y+circleY2,
                       clrButtonRed);
    }
    else
    {
      osd->DrawEllipse(t3+circleX1,   y+circleY1,
                       t3+circleX2,   y+circleY2,
                       clrNormalText);
    }


    osd->DrawText(t4, y, users.Get(i+current)->user.c_str(),
                  clrNormalText, clrTransparent,sFont,
                  t5-t4, 0, taLeft);

    osd->DrawText(t5, y, users.Get(i+current)->description.c_str(), clrNormalText, clrTransparent, sFont,
                  t6-t5, 0, taLeft);

    if( mode == IP)
    {
      asprintf(&tmp, "%s:%d", users.Get(i+current)->ip.c_str(), users.Get(i)->port);
      osd->DrawText(t6, y, tmp, clrNormalText, clrTransparent,sFont,
                    t7-t6, 0, taLeft);
      free(tmp);
      asprintf(&tmp, "%4d", users.Get(i)->pid);
      osd->DrawText(t7, y, tmp, clrNormalText, clrTransparent,sFont,
                    headerArea.x2-SCROLLWIDTH-SCROLLOFFSET-t7, 0, taLeft);
      free(tmp);
    }
    else
    {
      osd->DrawText(t6, y, users.Get(i+current)->channel.c_str(), clrNormalText, clrTransparent,sFont,
                    t7-t6, 0, taLeft);
      asprintf(&tmp, "%02ld:%02ldh", users.Get(i+current)->online/3600, (users.Get(i+current)->online%3600)/60);
      osd->DrawText(t7, y, tmp,clrNormalText, clrTransparent,sFont,
                    headerArea.x2-SCROLLWIDTH-SCROLLOFFSET-t7, 0, taLeft);
      free(tmp);
    }

    y += LINEHEIGHT;
  }



  // Scrollbar
  DrawScrollBar(users.Count(), maxNrOfLines);
}


/*
 *  Draw User Screen
 */
void cCsmonOsd::DrawClients( )
{
  char *tmp;
  stringstream  title;
  int y;
  int circleX1      = 8;
  int circleY1      = 7;
  int circleX2      = 18;
  int circleY2      = 17;

  int t1=5;          //Nr
  int t2=t1+3*chw;   //On
  int t3=t2+3*chw;   //AU
  int t4=t3+3*chw;   //User
  int t5=t4+10*chw;  //Protocol
  int t6=t5+10*chw;  //IP:Port /Channel
  int t7=headerArea.x2-SCROLLWIDTH-SCROLLOFFSET-6*chw;   //Online / PID

  // Header Area
  DrawBorder(headerArea.x1, headerArea.y1, headerArea.x2, headerArea.y2, 2, clrHeaderText, clrHeaderBkgr );

  y = headerArea.y1;
  title << "MPCS-Monitor - Monitor/Users-Info - " << csmonSetup.Server[currServer].Host;


  osd->DrawText(headerArea.x1,    y, title.str().c_str(), clrHeaderText,
                clrTransparent,sFont,headerArea.x2-headerArea.x1,0, taCenter);

  y += sFont->Height()+1;
  osd->DrawText(t1,    y, tr("Nr"),    clrHeaderText, clrTransparent,sFont);
  osd->DrawText(t2,    y, tr("On"),    clrHeaderText, clrTransparent,sFont);
  osd->DrawText(t3,    y, tr("AU"),    clrHeaderText, clrTransparent,sFont);
  osd->DrawText(t4,    y, tr("User"),  clrHeaderText, clrTransparent,sFont);
  osd->DrawText(t5,    y, tr("Protocol"),clrHeaderText, clrTransparent,sFont);

  if( mode == IP)
  {
    osd->DrawText(t6, y, tr("IP:Port"),  clrHeaderText, clrTransparent,sFont);
    osd->DrawText(t7, y, tr("PID"),      clrHeaderText, clrTransparent,sFont);
  }
  else
  {
    osd->DrawText(t6,    y, tr("Channel"), clrHeaderText, clrTransparent,sFont);
    osd->DrawText(t7,    y, tr("Online"),  clrHeaderText, clrTransparent,sFont);
  }


 //Delimiter Line
  osd->DrawRectangle(headerArea.x1, y, headerArea.x2, y+1, clrHeaderText);



  // Client Area
  y = clientArea.y1;
  for(int i=0; i<monitorUsers.Count()&& i<maxNrOfLines; i++)
  {
    if(!csmonSetup.realUserNumber)
    {
        asprintf(&tmp, "%2d",  i+1);
    } else {
        asprintf(&tmp, "%2d", monitorUsers.Get(i+current)->nr);
    }
    osd->DrawText(t1, y, tmp, clrNormalText, clrTransparent,sFont,  t2-t1, 0, taLeft);
    free(tmp);

    switch(monitorUsers.Get(i+current)->onstate)
    {
      case NORMAL:
        osd->DrawEllipse(t2+circleX1,   y+circleY1,
                         t2+circleX2,   y+circleY2,
                         clrButtonGreen);
        break;
      case SLEEPING:
        osd->DrawEllipse(t2+circleX1,   y+circleY1,
                         t2+circleX2,   y+circleY2,
                         clrNormalText);
        break;
      case FAKEUSER:
        osd->DrawEllipse(t2+circleX1,   y+circleY1,
                         t2+circleX2,   y+circleY2,
                         clrButtonRed);
        break;
      default:
        LOGERR("MPCSMON: Unknown onstate=%d\n", monitorUsers.Get(i+current)->onstate);
        break;
    }


    if( monitorUsers.Get(i+current)->authenticated > 0)
    {
      osd->DrawEllipse(t3+circleX1,   y+circleY1,
                       t3+circleX2,   y+circleY2,
                       clrButtonGreen);
    }
    else
      if( monitorUsers.Get(i+current)->authenticated == 0)
    {
      osd->DrawEllipse(t3+circleX1,   y+circleY1,
                       t3+circleX2,   y+circleY2,
                       clrButtonRed);
    }
    else
    {
      osd->DrawEllipse(t3+circleX1,   y+circleY1,
                       t3+circleX2,   y+circleY2,
                       clrNormalText);
    }


    osd->DrawText(t4, y, monitorUsers.Get(i+current)->user.c_str(),
                  clrNormalText, clrTransparent,sFont,
                  t5-t4, 0, taLeft);

    osd->DrawText(t5, y, monitorUsers.Get(i+current)->description.c_str(), clrNormalText, clrTransparent, sFont,
                  t6-t5, 0, taLeft);

    if( mode == IP)
    {
      asprintf(&tmp, "%s:%d", monitorUsers.Get(i+current)->ip.c_str(), monitorUsers.Get(i)->port);
      osd->DrawText(t6, y, tmp, clrNormalText, clrTransparent,sFont,
                    t7-t6, 0, taLeft);
      free(tmp);
      asprintf(&tmp, "%4d", monitorUsers.Get(i)->pid);
      osd->DrawText(t7, y, tmp, clrNormalText, clrTransparent,sFont,
                    headerArea.x2-SCROLLWIDTH-SCROLLOFFSET-t7, 0, taLeft);
      free(tmp);
    }
    else
    {
      osd->DrawText(t6, y, monitorUsers.Get(i+current)->channel.c_str(), clrNormalText, clrTransparent,sFont,
                    t7-t6, 0, taLeft);
      asprintf(&tmp, "%02ld:%02ldh", monitorUsers.Get(i+current)->online/3600, (monitorUsers.Get(i+current)->online%3600)/60);
      osd->DrawText(t7, y, tmp,clrNormalText, clrTransparent,sFont,
                    headerArea.x2-SCROLLWIDTH-SCROLLOFFSET-t7, 0, taLeft);
      free(tmp);
    }

    y += LINEHEIGHT;
  }

  // Scrollbar
  DrawScrollBar(monitorUsers.Count(), maxNrOfLines);
}


// Draw User Screen
void cCsmonOsd::DrawOtherClients( )
{
  char *tmp;
  stringstream  title;
  int y;
  int circleX1      = 8;
  int circleY1      = 7;
  int circleX2      = 18;
  int circleY2      = 17;

  int t1=5;          //Typ
  int t2=t1+4*chw;   //AU
  int t3=t2+3*chw;   //USER
  int t4=t3+10*chw;  //Protocol
  int t5=t4+10*chw;  //IP:Port /Channel
  int t6=headerArea.x2-SCROLLWIDTH-SCROLLOFFSET-6*chw;          // PID/Idle

  ShowOtherClients();

  // Header Area
  DrawBorder(headerArea.x1, headerArea.y1, headerArea.x2, headerArea.y2, 2, clrHeaderText, clrHeaderBkgr );

  y = headerArea.y1;
  title << "MPCS-Monitor - Reader-Info - " << csmonSetup.Server[currServer].Host;

  osd->DrawText(headerArea.x1,    y, title.str().c_str(), clrHeaderText,
                clrTransparent,sFont,headerArea.x2-headerArea.x1,0, taCenter);

  y += sFont->Height()+1;
  osd->DrawText(t1,    y, tr("Typ"),     clrHeaderText, clrTransparent,sFont);
  osd->DrawText(t2,    y, tr("AU"),      clrHeaderText, clrTransparent,sFont);
  osd->DrawText(t3,    y, tr("Reader"),    clrHeaderText, clrTransparent,sFont);
  osd->DrawText(t4,    y, tr("Protocol"),clrHeaderText, clrTransparent,sFont);

  if( mode == IP)
  {
    osd->DrawText(t5, y, tr("IP:Port"),  clrHeaderText, clrTransparent,sFont);
    osd->DrawText(t6, y, tr("PID"),      clrHeaderText, clrTransparent,sFont);
  }
  else
  {
    osd->DrawText(t5, y, tr("Channel"), clrHeaderText, clrTransparent,sFont);
    osd->DrawText(t6, y, tr("Idle"),    clrHeaderText, clrTransparent,sFont);
  }

  //Delimiter Line
  osd->DrawRectangle(headerArea.x1, y, headerArea.x2, y+1, clrHeaderText);

  // Client Area
  y = clientArea.y1;
  for(int i=0; i<otherUsers.Count()&& i<maxNrOfLines; i++)
  {
    osd->DrawText(t1, y, otherUsers.Get(i+current)->type.c_str(), clrNormalText, clrTransparent,sFont,  t2-t1, 0, taLeft);
    
    if( otherUsers.Get(i+current)->authenticated > 0)
      osd->DrawEllipse(t2+circleX1,   y+circleY1,
                       t2+circleX2,   y+circleY2,
                       clrButtonGreen);
    else
    if( otherUsers.Get(i+current)->authenticated == 0)
      osd->DrawEllipse(t2+circleX1,   y+circleY1,
                       t2+circleX2,   y+circleY2,
                       clrButtonRed);
    else
      osd->DrawEllipse(t2+circleX1,   y+circleY1,
                       t2+circleX2,   y+circleY2,
                       clrNormalText);

    osd->DrawText(t3, y, otherUsers.Get(i+current)->user.c_str(),
                  clrNormalText, clrTransparent,sFont,
                  t4-t3, 0, taLeft);
    osd->DrawText(t4, y, otherUsers.Get(i+current)->description.c_str(),
                  clrNormalText, clrTransparent, sFont,
                  t5-t4, 0, taLeft);

    if( mode == IP)
    {
      asprintf(&tmp, "%s:%d", otherUsers.Get(i+current)->ip.c_str(), otherUsers.Get(i)->port);
      osd->DrawText(t5, y, tmp, clrNormalText, clrTransparent,sFont,
                    t6-t5, 0, taLeft);
      free(tmp);
      asprintf(&tmp, "%4d", otherUsers.Get(i+current)->pid);
      osd->DrawText(t6, y, tmp, clrNormalText, clrTransparent,sFont,
                    headerArea.x2-SCROLLWIDTH-SCROLLOFFSET-t6, 0, taLeft);
      free(tmp);
    }
    else
    {
      osd->DrawText(t5, y, otherUsers.Get(i+current)->channel.c_str(),
                    clrNormalText, clrTransparent,sFont,
                    t6-t5, 0, taLeft);

      asprintf(&tmp, "%02ld:%02ldh", otherUsers.Get(i+current)->idle/3600,
                (otherUsers.Get(i+current)->idle%3600)/60);
      osd->DrawText(t6, y, tmp,clrNormalText,
                    clrTransparent,sFont,
                    headerArea.x2-SCROLLWIDTH-SCROLLOFFSET-t6, 0, taLeft);
      free(tmp);
    }
    y += LINEHEIGHT;
  }

  // Scrollbar
  DrawScrollBar(otherUsers.Count(), maxNrOfLines);
}

unsigned int calcLen(string str, unsigned int minLen)
{
  unsigned l   = str.length();
  unsigned res = minLen;

  if( l > minLen)
     res = l;
  return(res);
}

 // Draw User Screen
void cCsmonOsd::DrawLogs( )
{
  stringstream  title;
  int y;

  int t1=5;          //Time
  int t2=t1+8*chw;   //Typ
  int t3=t2+4*chw;   //USER
  int t4=t3+9*chw;   //Caid
  int t5=t4+6*chw;   //Status-Log

  // Header Area
  DrawBorder(headerArea.x1, headerArea.y1, headerArea.x2, headerArea.y2, 2, clrHeaderText, clrHeaderBkgr );
  y = headerArea.y1;
  title << "MPCS-Monitor - Log-Info - " << csmonSetup.Server[currServer].Host;
  osd->DrawText(headerArea.x1,    y, title.str().c_str(), clrHeaderText,
                clrTransparent,sFont,headerArea.x2-headerArea.x1,0, taCenter);

  y += sFont->Height()+1;

    //Delimiter Line
    osd->DrawRectangle(headerArea.x1, y, headerArea.x2, y+1, clrHeaderText);

    // show header description
    osd->DrawText(t1, y, tr("CS-Time"),	clrHeaderText, clrTransparent,sFont);
    osd->DrawText(t2, y, tr("Typ"),	clrHeaderText, clrTransparent,sFont);
    osd->DrawText(t3, y, tr("Name"),	clrHeaderText, clrTransparent,sFont);
    osd->DrawText(t4, y, tr("Caid"),	clrHeaderText, clrTransparent,sFont);
    osd->DrawText(t5, y, tr("Status-Log"),	clrHeaderText, clrTransparent,sFont);

  y += LINEHEIGHT;
  for(int i=current; i<logs.Count() && y<buttonArea.y1; i++)
  {
    int p = 5;
    osd->DrawText(p, y, logs.Get(i)->GetTime().c_str(), clrNormalText, clrTransparent,sFont);
    p += chw*8;
    osd->DrawText(p, y, logs.Get(i)->GetType().c_str(), clrNormalText, clrTransparent,sFont);
    p += chw*4;
    osd->DrawText(p, y, logs.Get(i)->GetUser().c_str(), clrNormalText, clrTransparent,sFont);
    p += chw*calcLen(logs.Get(i)->GetUser(), 9);
    osd->DrawText(p, y, logs.Get(i)->GetCaid().c_str(), clrNormalText, clrTransparent,sFont);
    p += chw*calcLen(logs.Get(i)->GetCaid(), 6);
    osd->DrawText(p, y, logs.Get(i)->GetLog().c_str(),  clrNormalText, clrTransparent,sFont);
    y += LINEHEIGHT;
  }

  for(int i=csmonSetup.LogBuffer; i<logs.Count(); i++)
    logs.Del(logs.Get(i));

  // Scrollbar
  DrawScrollBar(logs.Count(), maxNrOfLines);
}

void cCsmonOsd::DrawCommands()
{
  int y;

  stringstream  title;
  int textStart=20;
  int textLen  =headerArea.x2-headerArea.y1-SCROLLWIDTH -SCROLLOFFSET-10;

  y = headerArea.y1;

  title << "MPCS-Monitor - " <<  tr("Commands") << " " << csmonSetup.Server[currServer].Host;
  // Header Area
  DrawBorder(headerArea.x1, headerArea.y1, headerArea.x2, headerArea.y2, 2,
             clrHeaderText, clrHeaderBkgr );
  y = headerArea.y1;
  osd->DrawText(headerArea.x1, y, title.str().c_str(), clrHeaderText,
                clrTransparent,sFont,headerArea.x2-headerArea.x1,0, taCenter);
  y += sFont->Height()+1;

  //Delimiter Line
    osd->DrawRectangle(headerArea.x1, y, headerArea.x2, y+1, clrHeaderText);
  // show header description
  osd->DrawText(headerArea.x1, y, tr("Select Command with up/down key and with ok key confirm this"), clrHeaderText, clrTransparent,sFont, headerArea.x2-headerArea.x1,0, taCenter);
  
  y = clientArea.y1;

  for(int i=0; i< (int)commands.Count(); i++)
  {
    if( i == current)
    {
      DrawEclipseFrame(headerArea.x1, y, headerArea.x2, y+LINEHEIGHT, 10,
                       clrSelectBkgr, clrClientBkgr);
      osd->DrawText(textStart, y, commands.Get(i)->GetText().c_str(),
                    clrSelectText,clrTransparent,sFont,
                    textLen, 0, taLeft);
    }
    else
      osd->DrawText(textStart, y, commands.Get(i)->GetText().c_str(),
                    clrNormalText,clrTransparent,sFont,
                    textLen, 0, taLeft);
    y += LINEHEIGHT;
  }
}

eOSState cCsmonOsd::ProcessKey(eKeys Key)
{
  eOSState state = cOsdObject::ProcessKey(Key);
  if (state == osUnknown) {
    switch (Key) {
      case kRed:
        switch(view)
        {
          case USER:
            SwitchView(HIDEMONITOR);
            break;
          case HIDEMONITOR:
            SwitchView(READER);
            break;
          case READER:
            SwitchView(LOG);
            break;
          case LOG:
            SwitchView(USER);
            break;
          case COMMAND:
          case WAITFORCONFIRM:
            SwitchView(USER);
            break;

        }
        break;
      case kGreen:
          if(mode == IP)
            mode = CHANNEL;
          else
            mode = IP;
          DrawMenu();
        break;

      case kYellow:
        if(view != COMMAND && view != WAITFORCONFIRM )
          SwitchView(COMMAND);
        break;

      case kBlue:
        if(csmonSetup.NrServers >1)
        {
          currServer++;
          if(currServer >=csmonSetup.NrServers)
            currServer=0;
          SwitchView(USER);
          PleaseWait();
        }
        break;

      case kBack:
        if(view == COMMAND || view == WAITFORCONFIRM)
          SwitchView(USER);
        else
          return osEnd;
        break;
      case kOk:
        if( view == COMMAND)
        {
          Confirm(commands.Get(current)->GetText().c_str());
          view = WAITFORCONFIRM;
        }
        else
          if( view == WAITFORCONFIRM)
          {
            Send(commands.Get(current)->GetCommand().c_str());
            SwitchView(USER);
          }
        break;

      case kRight:
        Scroll(Key);
        DrawMenu();
        break;

      case kLeft:
        Scroll(Key);
        DrawMenu();
        break;

      case kUp:
        Scroll(Key);
        DrawMenu();
        break;
      case kDown:
        Scroll(Key);
        DrawMenu();
        break;

      default:
        break;
    }
  }
  return osContinue;
}


void cCsmonOsd::Scroll( eKeys Key )
{
  switch (Key)
  {
    case kUp:
      current--;
      break;
    case kDown:
      current++;
      break;

    case kRight:
      current +=maxNrOfLines;
      break;
    case kLeft:
      current -=maxNrOfLines;
      break;
    default:
      break;
  }


  switch(view)
  {
    case USER:
      if(current + maxNrOfLines > users.Count())
        current = users.Count()-maxNrOfLines;
      break;
    case  READER:
      if(current + maxNrOfLines > otherUsers.Count())
        current = otherUsers.Count()-maxNrOfLines;
      break;
    case  LOG:
      if(current + maxNrOfLines > logs.Count())
        current = logs.Count()-maxNrOfLines;
      break;
    case  COMMAND:
      if(current >= commands.Count())
        current = commands.Count()-1;
      break;
    default:
      break;
  }

  if( current < 0)
    current=0;
}

//----- Utiltities ----------

void cCsmonOsd::DrawScrollBar(int totalElements, int maxElements)
{
  int x1=clientArea.x2-SCROLLWIDTH;  //scrollstart
  int x2=clientArea.x2-SCROLLOFFSET; //scrollend

  if(maxElements < totalElements)
  {
    int y1 = clientArea.y1+10;
    int y2 = clientArea.y2-10;
    int height = y2-y1;
    float  perc = (float)maxElements / (float) totalElements;
    float  pos  = (float)current / (float) totalElements;
    DrawBorder(x1,
               y1,
               x2,
               y2,
               2,
               clrNormalText, clrClientBkgr);

    int yStart = (int) (y1+height*pos);
    int yEnd   = (int) (yStart + height*perc);
    DrawBorder(x1,
               yStart,
               x2,
               yEnd,
               0,
               clrNormalText, clrNormalText);
  }
}


bool cCsmonOsd::Confirm(string msg)
{
  msg += '?';
  DrawMessage(msg.c_str());

  return(true);
}

void cCsmonOsd::DrawMessage(const char *msg)
{
  DrawBorder(buttonArea.x1, buttonArea.y1, buttonArea.x2, buttonArea.y2, 2, clrHeaderBkgr, clrHeaderBkgr );

  osd->DrawText(buttonArea.x1, buttonArea.y1,
                msg,  clrHeaderText, clrTransparent,sFont,
                buttonArea.x2-buttonArea.x1, 0, taCenter);

  osd->Flush();
}



void cCsmonOsd::SetButton( const char * redText, const char * greenText, const char * yellowText,
                           const char * blueText )
{
  int border =2;
  int offsetX=6;
  int boxX   = (buttonArea.x2-buttonArea.x1-5*offsetX)/4;
  int boxY   =sFont->Height() + 5;
  int offsetY=((buttonArea.y2-buttonArea.y1)-boxY)/2;
  int x1,x2;
  DrawBorder(buttonArea.x1, buttonArea.y1, buttonArea.x2, buttonArea.y2, 2, clrHeaderBkgr, clrHeaderBkgr );

  x1 = buttonArea.x1+offsetX;
  x2 = buttonArea.x1+offsetX+boxX;
  if(redText)
  {
    DrawBorder(x1,
               buttonArea.y1+offsetY,
               x2,
               buttonArea.y1+offsetY+boxY,
               border, clrButtonBorder, clrButtonRed );
    osd->DrawText(x1+border, buttonArea.y1+offsetY+border,
                  redText,  clrButtonRedText, clrTransparent,sFont, x2 - x1, 0, taCenter);
  }

  x1 += offsetX+boxX;
  x2 += offsetX+boxX;
  if(greenText)
  {
    DrawBorder(x1,
               buttonArea.y1+offsetY,
               x2,
               buttonArea.y1+offsetY+boxY,
               border, clrButtonBorder, clrButtonGreen );
    osd->DrawText(x1+border, buttonArea.y1+offsetY+border,
                  greenText,  clrButtonGreenText, clrTransparent,sFont, x2 - x1, 0, taCenter);
  }

  x1 += offsetX+boxX;
  x2 += offsetX+boxX;

  if(yellowText)
  {
    DrawBorder(x1,
               buttonArea.y1+offsetY,
               x2,
               buttonArea.y1+offsetY+boxY,
               border, clrButtonBorder, clrButtonYellow );
    osd->DrawText(x1+border, buttonArea.y1+offsetY+border,
                  yellowText,  clrButtonYellowText, clrTransparent,sFont, x2 - x1, 0, taCenter);
  }

  x1 += offsetX+boxX;
  x2 += offsetX+boxX;
  if(blueText)
  {
    DrawBorder(x1,
               buttonArea.y1+offsetY,
               x2,
               buttonArea.y1+offsetY+boxY,
               border, clrButtonBorder, clrButtonBlue );
    osd->DrawText(x1+border, buttonArea.y1+offsetY+border,
                  blueText,  clrButtonBlueText, clrTransparent,sFont, x2 - x1, 0, taCenter);
  }
}



void cCsmonOsd::DrawBorder(int x1, int y1, int x2, int y2, int width, int color)
{
  for(int i=x1; i<=x2; i++)
  {
    // Draw Main rectangle and horizontal lines
    for(int w=0; w<width; w++)
    {
      osd->DrawPixel(i, y1+w, color);
      osd->DrawPixel(i, y2-w, color);
    }
  }
  // Draw vertical lines
  for(int i=y1; i<=y2; i++)
  {
    for(int w=0; w<width; w++)
    {
      osd->DrawPixel(x1+w, i, color);
      osd->DrawPixel(x2-w, i, color);
    }
  }
}

void cCsmonOsd::DrawBorder(int x1, int y1, int x2, int y2, int width, int borderColor, int fillColor)
{
  DrawBorder(x1,y1, x2, y2, width, borderColor);
  osd->DrawRectangle(x1+width, y1+width, x2-width, y2-width, fillColor);
}

void cCsmonOsd::DrawEclipseFrame( int x1, int y1, int x2, int y2, int radius, int color, int background )
{
  osd->DrawRectangle(x1, y1, x2, y2, color);
  DrawEclipseBorder(x1, y1, x2, y2, radius, background);
}


void cCsmonOsd::DrawEclipseBorder( int x1, int y1, int x2, int y2, int radius, int color )
{
  osd->DrawEllipse(x2-radius, y1, x2, y1+radius, color, -1);
  osd->DrawEllipse(x1, y1, x1+radius, y1+radius, color, -2);
  osd->DrawEllipse(x1, y2-radius, x1+radius, y2, color, -3);
  osd->DrawEllipse(x2-radius, y2-radius, x2, y2, color, -4);
}


void cCsmonOsd::DisplayBitmap() {
  osd->Flush();
}

void cCsmonOsd::ClearBitmap() {
  osd->DrawRectangle(totalArea.x1, totalArea.y1, totalArea.x2, totalArea.y2, clrClientBkgr);
}

void cCsmonOsd::AlignCoordinates(int x1, int  y1, int &x2, int &y2, int bpp)
{
  while ((x2 - x1 + 1) % (8 / bpp) != 0)
    x2++;

  while ((y2 - y1 + 1) % (8 / bpp) != 0)
    y2++;

}
