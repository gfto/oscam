//
// C++ Implementation:
//
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include <sstream>
#include "setup.h"

using namespace std;
static const char *themes[MAXTHEME] = { "DeepBlue", "Engima", "Elchi"};
const csmonTheme csmonThemes[MAXTHEME] =
{
  // DeepBlue
  {
    0xC832557A, //clrHeaderBkgr
    0xC8339999, //clrHeaderText
    0xC80C0C0C, //clrClientBkgr
    0xFF9A9A9A, //clrNormalText
    0xFF9A9A9A, //clrSelectText
    0xC832557A, //clrSelectBkgr
    0xFF992900, //clrButtonRed
    0xFF336600, //clrButtonGreen
    0xFFCE7B00, //clrButtonYellow
    0xFF253F5A, //clrButtonBlue
    0xFF9A9A9A, //clrButtonRedText
    0xC80C0C0C, //clrButtonGreenText
    0xC80C0C0C, //clrButtonYellowText
    0xFF9A9A9A, //clrButtonBlueText
    0xC80C0C0C, //clrButtonBorder
  },
  // Engima
  {
    0xB84158BC, //clrHeaderBkgr
    0xFFFFFFFF, //clrHeaderText
    0xB8DEE5FA, //clrClientBkgr
    0xFF000000, //clrNormalText
    0xFF000000, //clrSelectText
    0xB8BFC9E6, //clrSelectBkgr
    0xB8C40000, //clrButtonRed
    0xB800C400, //clrButtonGreen
    0xB8C4C400, //clrButtonYellow
    0xB84158BC, //clrButtonBlue
    0xFFFFFFFF, //clrButtonRedText
    0xFFFFFFFF, //clrButtonGreenText
    0xFFFFFFFF, //clrButtonYellowText
    0xFFFFFFFF, //clrButtonBlueText B80000C4
    0xFF000000, //clrButtonBorder
  },
  // Elchi
  {
    0xCC2BA7F1, //clrHeaderBkgr
    0xFF000000, //clrHeaderText
    0x77000066, //clrClientBkgr
    0xFFFFFFFF, //clrNormalText
    0xFF000000, //clrSelectText
    0xCC2BA7F1, //clrSelectBkgr
    0xCCCC1111, //clrButtonRed
    0xCC22BB22, //clrButtonGreen
    0xCCEEEE22, //clrButtonYellow
    0xCC2233CC, //clrButtonBlue
    0xFFFCFCFC, //clrButtonRedText
    0xFF000000, //clrButtonGreenText
    0xFF000000, //clrButtonYellowText
    0xFFFFFFFF, //clrButtonBlueText
    0xC80C0C0C, //clrButtonBorder
  }
};



static const char allowed[]   = { " abcdefghijklmnopqrstuvwxyzABCDEFGHIKLMNOPQRSTUVWXYZ0123456789.-_" };

cCsmonSetup::cCsmonSetup()
{
  NrServers = 1;

  for(int i=0; i<MAXSERVER;i++)
  {
    strcpy(Server[i].Host, "localhost");
    Server[i].Port  = 988;
    Server[i].Login[0] = '\0';
    Server[i].Passwd[0] = '\0';
  }

  StatusTimer= 5;
  LogTimer   = 60;
  LogBuffer  = 200;

  
  theme         = DEEPBLUE;
  realUserNumber = false;
  osdOffsetX    =0;
  osdOffsetY    =0;    
}

bool cCsmonSetup::SetupParse( const char * Name, const char * Value )
{
  if (strcmp(Name, "NrServers" )    == 0) NrServers = atoi(Value);
  else if (strcmp(Name, "Host1" )  == 0) snprintf(Server[0].Host, sizeof(Server[0].Host), Value);
  else if (strcmp(Name, "Port1" )  == 0) Server[0].Port = atoi(Value);
  else if (strcmp(Name, "Login1" ) == 0) snprintf(Server[0].Login,  sizeof(Server[0].Login), Value);
  else if (strcmp(Name, "Password1" )== 0) snprintf(Server[0].Passwd, sizeof(Server[0].Passwd), Value);
  
  else if (strcmp(Name, "Host2" )  == 0) snprintf(Server[1].Host, sizeof(Server[1].Host), Value);
  else if (strcmp(Name, "Port2" )  == 0) Server[1].Port = atoi(Value);
  else if (strcmp(Name, "Login2" ) == 0) snprintf(Server[1].Login,  sizeof(Server[1].Login), Value);
  else if (strcmp(Name, "Password2" )== 0) snprintf(Server[1].Passwd, sizeof(Server[1].Passwd), Value);

  else if (strcmp(Name, "Host3" )  == 0) snprintf(Server[2].Host, sizeof(Server[2].Host), Value);
  else if (strcmp(Name, "Port3" )  == 0) Server[2].Port = atoi(Value);
  else if (strcmp(Name, "Login3" ) == 0) snprintf(Server[2].Login,  sizeof(Server[2].Login), Value);
  else if (strcmp(Name, "Password3" )== 0) snprintf(Server[2].Passwd, sizeof(Server[2].Passwd), Value);

  else if (strcmp(Name, "Host4" )  == 0) snprintf(Server[3].Host, sizeof(Server[3].Host), Value);
  else if (strcmp(Name, "Port4" )  == 0) Server[3].Port = atoi(Value);
  else if (strcmp(Name, "Login4" ) == 0) snprintf(Server[3].Login,  sizeof(Server[3].Login), Value);
  else if (strcmp(Name, "Password4" )== 0) snprintf(Server[3].Passwd, sizeof(Server[3].Passwd), Value);
  
  else if (strcmp(Name, "Host5" )  == 0) snprintf(Server[4].Host, sizeof(Server[4].Host), Value);
  else if (strcmp(Name, "Port5" )  == 0) Server[4].Port = atoi(Value);
  else if (strcmp(Name, "Login5" ) == 0) snprintf(Server[4].Login,  sizeof(Server[4].Login), Value);
  else if (strcmp(Name, "Password5" )== 0) snprintf(Server[4].Passwd, sizeof(Server[4].Passwd), Value);
  
  else if (strcmp(Name, "Host6" )  == 0) snprintf(Server[5].Host, sizeof(Server[5].Host), Value);
  else if (strcmp(Name, "Port6" )  == 0) Server[5].Port = atoi(Value);
  else if (strcmp(Name, "Login6" ) == 0) snprintf(Server[5].Login,  sizeof(Server[5].Login), Value);
  else if (strcmp(Name, "Password6" )== 0) snprintf(Server[5].Passwd, sizeof(Server[5].Passwd), Value);

  else if (strcmp(Name, "Host7" )  == 0) snprintf(Server[6].Host, sizeof(Server[6].Host), Value);
  else if (strcmp(Name, "Port7" )  == 0) Server[6].Port = atoi(Value);
  else if (strcmp(Name, "Login7" ) == 0) snprintf(Server[6].Login,  sizeof(Server[6].Login), Value);
  else if (strcmp(Name, "Password7" )== 0) snprintf(Server[6].Passwd, sizeof(Server[6].Passwd), Value);

  else if (strcmp(Name, "Host8" )  == 0) snprintf(Server[7].Host, sizeof(Server[7].Host), Value);
  else if (strcmp(Name, "Port8" )  == 0) Server[7].Port = atoi(Value);
  else if (strcmp(Name, "Login8" ) == 0) snprintf(Server[7].Login,  sizeof(Server[7].Login), Value);
  else if (strcmp(Name, "Password8" )== 0) snprintf(Server[7].Passwd, sizeof(Server[7].Passwd), Value);

  else if (strcmp(Name, "StatusTimer" ) == 0) StatusTimer = atoi(Value);
  else if (strcmp(Name, "LogTimer" )    == 0) LogTimer = atoi(Value);
  else if (strcmp(Name, "LogBuffer" )    == 0) LogBuffer = atoi(Value);
  else if (strcmp(Name, "Theme" )        == 0) theme         = (enum MyThymes) atoi(Value);
  else if (strcmp(Name, "RealUserNumber" )   == 0) realUserNumber   =  atoi(Value);
  else if (strcmp(Name, "OSDOffsetX" )   == 0) osdOffsetX   =  atoi(Value);
  else if (strcmp(Name, "OSDOffsetY" )   == 0) osdOffsetY   =  atoi(Value);
        
  else return false;

    return true;
}

//--------------------------------------------------------------

cCsmonSetupPage::cCsmonSetupPage( void )
{
  Set();
}

void cCsmonSetupPage::Set( void )
{
  char *text = NULL;
  Add(new cMenuEditIntItem(tr("Nr of Servers"),      &csmonSetup.NrServers,1, MAXSERVER));

  for(int i=0; i<csmonSetup.NrServers; i++)
  {
    asprintf(&text, "%s %d", tr("Host"), i+1);
    Add(new cMenuEditStrItem(text, csmonSetup.Server[i].Host, sizeof(csmonSetup.Server[i].Host) + 1, allowed));
    free(text);

    asprintf(&text, "%s %d", tr("Port"), i+1);
    Add(new cMenuEditIntItem(text, &csmonSetup.Server[i].Port,1,65535));
    free(text);

    asprintf(&text, "%s %d", tr("Login"), i+1);
    Add(new cMenuEditStrItem(text,csmonSetup.Server[i].Login, sizeof(csmonSetup.Server[i].Login) + 1, allowed));
    free(text);

    asprintf(&text, "%s %d", tr("Password"), i+1);
    Add(new cMenuEditStrItem(text,csmonSetup.Server[i].Passwd, sizeof(csmonSetup.Server[i].Passwd) + 1, allowed));
    free(text);
  }
  
  Add(new cMenuEditIntItem(tr("Resend Status (s)"),   &csmonSetup.StatusTimer,1,120));
  Add(new cMenuEditIntItem(tr("Resend Log (s)"),      &csmonSetup.LogTimer,1,120));
  Add(new cMenuEditIntItem(tr("Log-Buffer-Size"),     &csmonSetup.LogBuffer,200,2000));

  Add(new cMenuEditStraItem(tr("Skin"), (int*)  &csmonSetup.theme, (int)MAXTHEME, themes));
  Add(new cMenuEditBoolItem(tr("RealUserNumber"),  &csmonSetup.realUserNumber));
  
  Add(new cMenuEditIntItem(tr("OSD-Offset X"),  &csmonSetup.osdOffsetX,-100,100));
  Add(new cMenuEditIntItem(tr("OSD-Offset Y"),  &csmonSetup.osdOffsetY,-100,100));
    
}

void cCsmonSetupPage::Store( void )
{
  char *text = NULL;
  SetupStore("NrServers",  csmonSetup.NrServers);
  for(int i=0; i<MAXSERVER; i++)
  {
    asprintf(&text, "Host%d", i+1);
    SetupStore(text,   csmonSetup.Server[i].Host);
    free(text);

    asprintf(&text, "Port%d", i+1);
    SetupStore(text,   csmonSetup.Server[i].Port);
    free(text);
    asprintf(&text, "Login%d", i+1);
    SetupStore(text,  csmonSetup.Server[i].Login);
    free(text);
    asprintf(&text, "Password%d", i+1);
    SetupStore(text, csmonSetup.Server[i].Passwd);
    free(text);
  }
  SetupStore("StatusTimer", csmonSetup.StatusTimer);
  SetupStore("LogTimer",    csmonSetup.LogTimer);
  SetupStore("LogBuffer",   csmonSetup.LogBuffer);
  SetupStore("Theme",       csmonSetup.theme);
  SetupStore("RealUserNumber",  csmonSetup.realUserNumber);
  SetupStore("OSDOffsetX",  csmonSetup.osdOffsetX);
  SetupStore("OSDOffsetY",  csmonSetup.osdOffsetY);
}


eOSState cCsmonSetupPage::ProcessKey( eKeys Key )
{
  int  prev_NrServers = csmonSetup.NrServers;
  
  eOSState state = cOsdMenu::ProcessKey(Key);

  if( prev_NrServers != csmonSetup.NrServers){
    Clear();
    Set();
    Display();
  }
  
  if (state == osUnknown) {
    switch (Key) {
      case kOk: Store();
      state = osBack;
      break;
      default: break;
    }
  }
  return state;

}
