from enigma import *
from Screens.Screen import Screen
from Plugins.Plugin import PluginDescriptor

class MpcsMonStarter(Screen):
	skin = """
		<screen position="1,1" size="1,1" title="MpcsMon" >
                </screen>"""

        def __init__(self, session, args = None):
        	self.skin = MpcsMonStarter.skin
		Screen.__init__(self, session)
		self.container=eConsoleAppContainer()
		self.container.appClosed.get().append(self.finished)
		self.runapp()
		
	def runapp(self):
		eDBoxLCD.getInstance().lock()
		eRCInput.getInstance().lock()
		fbClass.getInstance().lock()
		self.container.execute("/usr/plugins/mpcsmon")

	def finished(self,retval):
		fbClass.getInstance().unlock()
		eRCInput.getInstance().unlock()
		eDBoxLCD.getInstance().unlock()
		self.close()

def main(session, **kwargs):
	session.open(MpcsMonStarter)

def Plugins(**kwargs):
	return PluginDescriptor(name="MpcsMon", description="MPCS Monitor", where = PluginDescriptor.WHERE_PLUGINMENU, fnc=main)
	